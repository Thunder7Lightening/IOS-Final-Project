//
//  GameScene.swift
//  MazeBall
//
//  Created by Thunder7Lightening on 2018/6/23.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import SpriteKit
import CoreMotion

class GameScene: SKScene, SKPhysicsContactDelegate {
    let manager = CMMotionManager()
    var player = SKSpriteNode()
    var endNode = SKSpriteNode()
    
    var levelTimerLabel = SKLabelNode(fontNamed: "ArialMT")
    
    //Immediately after leveTimerValue variable is set, update label's text
    var levelTimerValue: Int = 10 {
        didSet {
            levelTimerLabel.text = "Time left: \(levelTimerValue)"
        }
    }
    
    func setTimer(){
        levelTimerLabel.fontColor = SKColor.black
        levelTimerLabel.fontSize = 40
        levelTimerLabel.position = CGPoint(x: size.width/2, y: size.height*9/10)
        levelTimerLabel.text = "Time left: \(levelTimerValue)"
        addChild(levelTimerLabel)
        
        let wait = SKAction.wait(forDuration: 1) //change countdown speed here
        let block = SKAction.run({
            [unowned self] in
            
            if self.levelTimerValue > 0{
                self.levelTimerValue -= 1
            }else{
                self.removeAction(forKey: "countdown")
                self.showAlertForWinAndLose(title: "Oops...", message: "You lose the game T_T")
            }
        })
        let sequence = SKAction.sequence([wait,block])
        
        run(SKAction.repeatForever(sequence), withKey: "countdown")
    }
    
    func restartTheGame(){
        if let newScene = GameScene(fileNamed: "GameScene"){
            newScene.scaleMode = self.scaleMode
            let animation = SKTransition.fade(withDuration: 1.0)
            self.view?.presentScene(newScene, transition: animation)
        }
    }
    
    func pauseOrResume(){
        if let pauseValue = scene?.view?.isPaused{
            scene?.view?.isPaused = !pauseValue
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        pauseOrResume()
        showAlertForPause(title: "Pause", message: "")
    }
    
    deinit {
        print("Restart the game")
    }
    
    override func didMove(to view: SKView) {
        self.physicsWorld.contactDelegate = self
        
        player = self.childNode(withName: "player") as! SKSpriteNode
        endNode = self.childNode(withName: "endNode") as! SKSpriteNode
        
        setTimer()
        
        manager.startAccelerometerUpdates()
        manager.accelerometerUpdateInterval = 0.1
        manager.startAccelerometerUpdates(to: OperationQueue.main){
            (data, error) in
            self.physicsWorld.gravity = CGVector(dx: CGFloat((data?.acceleration.x)! * 10), dy: CGFloat((data?.acceleration.y)!) * 10)
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA
        let bodyB = contact.bodyB
        
        if bodyA.categoryBitMask == 1 && bodyB.categoryBitMask == 2 || bodyA.categoryBitMask == 2 && bodyB.categoryBitMask == 1 {
            showAlertForWinAndLose(title: "Congratulations!!", message: "You win the game!")
        }
    }
    
    func showAlertForPause(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let resumeAction = UIAlertAction(title: "Resume", style: .cancel) { _ in self.pauseOrResume() }
        let restartAction = UIAlertAction(title: "Restart", style: .destructive) {
            _ in
            self.pauseOrResume()
            self.restartTheGame()
        }
        alertController.addAction(resumeAction)
        alertController.addAction(restartAction)
        
        self.view?.window?.rootViewController?.present(alertController, animated: true, completion: nil)
        pauseOrResume()
    }
    
    func showAlertForWinAndLose(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let restartAction = UIAlertAction(title: "Restart", style: .cancel) {
            _ in
            self.pauseOrResume()
            self.restartTheGame()
        }
        alertController.addAction(restartAction)
        
        self.view?.window?.rootViewController?.present(alertController, animated: true, completion: nil)
        pauseOrResume()
    }
    
    override func update(_ currentTime: TimeInterval) {
        /* Called before each frame is rendered */
    }
}
